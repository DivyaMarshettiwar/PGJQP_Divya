// WAP to display your name on the screen

import java.util.*;
import java.util.Scanner;
class Name
{

 String name;
 void getdata()
 {
   
   System.out.println("Enter your name");
   Scanner s = new Scanner(System.in);
   name = s.nextLine();
 }


 void display()
 {
   System.out.println("Your name is : " + name);
 }


 public static void main(String[] args)
 {
   Name n = new Name();
   n.getdata();
   n.display();
 }
}