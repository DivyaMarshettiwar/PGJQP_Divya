// WAP to displayyour friend's name on the screen

import java.util.*;
import java.util.Scanner;

class Friend_name
{

 String name;

 void getdata()
 {
  System.out.println("Enter your Friend's name : ");
  Scanner s = new Scanner(System.in);
  name = s.nextLine();
 }

 void display()
 { 
  System.out.println("Friend's name is : " + name);
 }

 public static void main(String[] args)
 {
  Friend_name n = new Friend_name();
  n.getdata();
  n.display();
 }
}