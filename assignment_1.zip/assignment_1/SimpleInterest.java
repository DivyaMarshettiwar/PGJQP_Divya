//14. WAP to calculate the simple interest

import java.util.Scanner;

class SimpleInterest
{
  float si, principal, rate ,years;
  
 void getdata()
 {
   Scanner s = new Scanner(System.in);

   System.out.println("Enter the principal amount, rate of interest and the number of years : ");
   principal = s.nextFloat();
   rate = s.nextFloat();
   years = s.nextFloat();
 }

  void calculation()
  {
    si = (principal * rate * years) / 100;
  }

  void display()
  {
    System.out.println("Simple Interest : Rs. " + si);
  }

  public static void main(String[] args)
  {
    SimpleInterest s = new SimpleInterest();
    s.getdata();
    s.calculation();
    s.display();
  }
}