//5. WAP to calculate the increment of a given number by 1

import java.util.Scanner;
class Increment
{
  int number;
  
  void getdata()
  {
   System.out.println("Enter any number : ");
   Scanner s = new Scanner(System.in);
   number = s.nextInt();
  }

  void display()
  {
   System.out.println("The incremented number is : " + (number+1));
  } 

  public static void main(String[] args)
  {
   Increment i = new Increment();
   i.getdata();
   i.display(); 
  }
}