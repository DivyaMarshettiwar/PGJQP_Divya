//4. WAP to declare variables of each data type and display it on the screen (int, char, float)

import java.util.Scanner;

class Values
{  
  int roll_no;
  float percentage;
  char section;
  
  void getdata()
  {
     Scanner s = new Scanner(System.in);
   
   System.out.println("Enter your section : ");
   section = s.next().charAt(0);

   System.out.println("Enter your roll_no : ");
   roll_no = s.nextInt();

   System.out.println("Enter your percentage : ");
   percentage = s.nextFloat();
  }

  void display()
  { 
   System.out.println("Section : " + section);
   System.out.println("Roll_no : " + roll_no);
   System.out.println("Percentage : " + percentage + "%");
  }

  public static void main(String[] args)
 { 
   Values v = new Values();
   v.getdata();
   v.display();
 }
   
}