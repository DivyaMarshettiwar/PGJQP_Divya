//10. WAP to multiply two floating point numbers

import java.util.Scanner;

class Mul_float
{
  float num1, num2, mul;

  void getdata()
  {
    System.out.println("Enter the two float values : ");
    Scanner s = new Scanner(System.in);
    num1 = s.nextFloat();
    num2 = s.nextFloat();
  }

  void multiply()
  {
    mul = num1 * num2;
  }

  void display()
  {
    System.out.println("Multiplication : " + mul );
  }
  
  public static void main(String[] args)
  {
    Mul_float m = new Mul_float();
    m.getdata();
    m.multiply();
    m.display();
  }
}