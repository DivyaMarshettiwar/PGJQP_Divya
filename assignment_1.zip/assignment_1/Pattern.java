//17. WAP to display the following pattern

class Pattern
{
  public static void main(String[] args)
  {
    System.out.println("I LIKE");
    System.out.println("\t\t\ JAVA PROGRAMMING");
  }
}