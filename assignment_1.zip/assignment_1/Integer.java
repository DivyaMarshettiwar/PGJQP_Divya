//3. WAP to print an Integer (Entered by the User)


import java.util.Scanner;
class Integer
{
 int number;

 void getdata()
 {
  System.out.println("Enter any Integer value:");
  Scanner s = new Scanner(System.in);
  number = s.nextInt();
 }

 void display()
 {
  System.out.println("The number is : " + number);
 }
  public static void main(String[] args)
  {
     Integer i = new Integer();
     i.getdata();
     i.display();
  }
}