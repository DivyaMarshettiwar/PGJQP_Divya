//13. WAP to calculate the area of circle

import java.util.Scanner;
  
class Area_circle
{ 
  double radius, area, pi=3.14;
  
  void getdata()
  {
    System.out.println("Enter the radius of the circle : ");
    Scanner s = new Scanner(System.in);
    radius = s.nextDouble();
  }

  void area()
  {
    area = pi * (radius * radius); 
  }

  void display()
  {
    System.out.println("The Area of the Circle is : " + area );
  }
  
  public static void main(String[] args)
  {
    Area_circle a = new Area_circle();
    a.getdata();
    a.area();
    a.display();
  }
}