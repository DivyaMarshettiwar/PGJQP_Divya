//15. WAP to find the average of 5 numbers

import java.util.Scanner;
 
class Average
{
  int num1, num2, num3, num4, num5, avg=0;
  
  void getdata()
  {
    Scanner s = new Scanner(System.in);
    System.out.println("Enter the five numbers : ");
    num1 = s.nextInt();
    num2 = s.nextInt();
    num3 = s.nextInt();
    num4 = s.nextInt();
    num5 = s.nextInt();
  }

  void average()
  {
    avg = (num1 + num2 + num3 + num4 + num5) / 5;
  }

  void display()
  {
    System.out.println("Average : " + avg);
  }

  public static void main(String[] args)
  {
   Average a = new Average();
   a.getdata();
   a.average();
   a.display();
  }
}