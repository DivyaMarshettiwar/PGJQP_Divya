//8. WAP to calculate the multiplication of three numbers

import java.util.Scanner;

class Numbers_mul
{
  int num1, num2, num3, mul;
  
  void getdata()
  { 
    System.out.println("Enter the three numbers : ");
    Scanner s  = new Scanner(System.in);
    num1 = s.nextInt();
    num2 = s.nextInt();
    num3 = s.nextInt();
  }

  void multiply()
  {
    mul = num1 * num2 * num3;
  }
  
  void display()
  {
    System.out.println("The multiplication is : " + mul);
  }
  
  public static void main(String[] args)
  {
   Numbers_mul n = new Numbers_mul();
   n.getdata();
   n.multiply();
   n.display();
  }
}