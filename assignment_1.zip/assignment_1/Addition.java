//7. WAP to calculate addition of two numbers

import java.util.Scanner;

class Addition 
{
  int num1,num2,addition;
  
  void getdata()
  {
    System.out.println("Enter the two numbers : ");
    Scanner s = new Scanner(System.in);
    num1 = s.nextInt();
    num2 = s.nextInt();
  }

  void add()
  {
    addition = num1 + num2;
  }

  void display()
  {
    System.out.println("The addition is : " + addition);
  }

  public static void main(String[] args)
  {
    Addition a = new Addition();
    a.getdata();
    a.add();
    a.display();
  }
}