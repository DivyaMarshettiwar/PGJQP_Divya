//6. WAP to calculate the increment of a given number by 7

import java.util.Scanner;
class AddSeven
{
  int number;

  void getdata()
  {
    System.out.println("Enter any number : ");
    Scanner s = new Scanner(System.in);
    number = s.nextInt();
  }

  void display()
  {
    System.out.println("The incremented the number by 7 is : " + (number + 7));
  }

  public static void main(String[] args)
  {
    AddSeven a = new AddSeven();
    a.getdata();
    a.display();
  }
}