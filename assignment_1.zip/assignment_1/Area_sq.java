//11. WAP to calculate the area of Square

import java.util.Scanner;

class Area_sq
{
  int side, area;
 
  void getdata()
  {
     System.out.println("Enter the side of the square : ");
     Scanner s = new Scanner(System.in);
     side = s.nextInt();
  }

  void area_sq()
  {
    area = side * side;
  }

  void display()
  {
    System.out.println("The area of square is : " + area + " sq units");
  }

  public static void main(String[] args)
  {
    Area_sq a = new Area_sq();
    a.getdata();
    a.area_sq();
    a.display();
  }
}