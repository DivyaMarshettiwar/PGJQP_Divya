//21. WAP to check number is divisible by 9 or not.

import java.util.Scanner;

class Divisible_9
{
   int number;

   void getdata()
   {
     System.out.println("Enter any number : ");
     Scanner sc = new Scanner(System.in);
     number = sc.nextInt();
   }
   void process()
   {
     if(number%9 == 0)
     System.out.println(number + " is divisible by 9");
     else
     System.out.println(number + " is NOT divisible by 9");
   }
   public static void main(String[] args)
   {
     Divisible_9 d = new Divisible_9();
     d.getdata();
     d.process();
   }
}