//5. WAP to find greater of two numbers.

import java.util.Scanner;
class Greater_of_two
{
  int num1, num2;
 
  void getdata()
  {
    System.out.println("Enter the two numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
  }

  void process()
  {
    if(num1 > num2)
    System.out.println(num1 + " is greater");
    else if(num2 > num1)
    System.out.println(num2 + " is greater");
    else
    System.out.println("EQUAL");
  }

  public static void main(String[] args)
  {
    Greater_of_two g = new Greater_of_two();
    g.getdata();
    g.process();
  }
}