//7. WAP to check whether a nummber is +ve, -ve or zero.

import java.util.Scanner;

class PosNegZero
{  
  int number;
 
  void getdata()
  {
    System.out.println("Enter a number : ");
    Scanner sc = new Scanner(System.in);
    number = sc.nextInt();
  }

  void process()
  {
     if(number > 0)
     System.out.println("POSITIVE");
     else if(number < 0)
     System.out.println("NEGATIVE");
     else
     System.out.println("ZERO");
  }

  public static void main(String[] args)
  {
    PosNegZero pnz = new PosNegZero();
    pnz.getdata();
    pnz.process();
  }
}
