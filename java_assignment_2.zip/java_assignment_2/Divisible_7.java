//20. WAP to check whether number is divisible by 7 or not.

import java.util.Scanner;

class Divisible_7
{
  int number;
  void getdata()
  {
    System.out.println("Enter a number : ");
    Scanner sc = new Scanner(System.in);
    number = sc.nextInt();
  }
  void process()
  {
    if(number%7 == 0)
    System.out.println(number + " is divisible by 7 ");
    else
    System.out.println(number + " is NOT divisible by 7 ");
  } 
  public static void main(String[] args)
  {
    Divisible_7 d = new Divisible_7();
    d.getdata();
    d.process();
  }
}