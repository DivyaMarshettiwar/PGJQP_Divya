//13. WAP to swap two numbers.

import java.util.Scanner;

class Swap
{
  int num1, num2, temp;
  
  void getdata()
  {
    System.out.println("Enter the two numbers : "); 
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
  }
 
  void process()
  {
    temp = num1;
    num1 = num2;
    num2 = temp;
  }

  void display()
  {
    System.out.println("The numbers after swap is : ");
    System.out.println("num1 is " + num1);
    System.out.println("num2 is "+ num2);
  }

  public static void main(String[] args)
  {
    Swap s = new Swap();
    s.getdata();
    s.process();
    s.display();
  }
}