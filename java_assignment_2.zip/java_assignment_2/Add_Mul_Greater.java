//22. WAP to perform addition and multiplication of two numbers and then find the Greater value.

import java.util.Scanner;
class Add_Mul_Greater
{
   int num1, num2, add=0, mul=0;
   void getdata()
   {
     System.out.println("Enter the two numbers : ");
     Scanner sc = new Scanner(System.in);
     num1 = sc.nextInt();
     num2 = sc.nextInt();
   }
   void addition()
   {
     add = num1 + num2;
   }
   void multiplication()
   {
     mul = num1 * num2;
   }
   void greater()
   {
      if( add > mul )
      System.out.println(add + " is greater");
      else
      System.out.println(mul + " is greater");
   } 
   public static void main(String[] args)
   {
     Add_Mul_Greater a = new Add_Mul_Greater();
     a.getdata();
     a.addition();
     a.multiplication();
     a.greater();
   }
}