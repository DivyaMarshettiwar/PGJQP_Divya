//11. WAP to check wheather the entered character is uppercase or lower case.

import java.util.Scanner;

class Upper_Lower_Case
{
   char ch;
   int ascii;
   void getdata()
   {
     System.out.println("Enter any Character : ");
     Scanner sc = new Scanner(System.in);
     ch = sc.next().charAt(0);
     ascii=ch;
   }

   void check()
   {
     if(ascii>=65 && ascii<=90 )
     System.out.println("UPPER CASE");
     else if(ascii>=97 && ascii<=122)
     System.out.println("LOWER CASE"); 
     else
     System.out.println("Invalid");
   }
 

   public static void main(String[] args)
   {
     Upper_Lower_Case c = new Upper_Lower_Case();
     c.getdata();
     c.check();
   }

}