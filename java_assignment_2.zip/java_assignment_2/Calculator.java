//29. WAP to design calculator using switch case.

import java.util.Scanner;
class Calculator
{
  int num1, num2,ch;
  void getdata()
  {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the two numbers : ");
    num1 = sc.nextInt();
    num2 = sc.nextInt();
    System.out.println("Enter your choice : ");
    System.out.println("1.Addition");
    System.out.println("2.Subtraction");
    System.out.println("3.Multiplication");
    System.out.println("4.Division");
    ch = sc.nextInt();
  }
  void process()
  {
    switch(ch)
    {
      case 1: System.out.println(num1 + num2);break;
      case 2: System.out.println(num1 - num2);break;
      case 3: System.out.println(num1 * num2);break;
      case 4: System.out.println(num1 / num2);break;
      default: System.out.println("Invalid");
    }
  }
  public static void main(String[] args)
  {
    Calculator c  = new Calculator();
    c.getdata();
    c.process();
  }
}