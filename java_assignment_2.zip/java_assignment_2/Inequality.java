//9. WAP to check the inequality of two numbers.

import java.util.Scanner;

class Inequality
{
  int num1, num2;
  
  void getdata()
  {
    System.out.println("Enter the two numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
  }

  void process()
  {
    if(num1 != num2)
    System.out.println("NOT EQUAL");
    else
    System.out.println("EQUAL");
  }

  public static void main(String[] args)
  {
    Inequality i = new Inequality();
    i.getdata();
    i.process();
  }
}