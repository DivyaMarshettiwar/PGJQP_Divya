//26. WAP to check whether the entered characte is vowel or consonant.

import java.util.Scanner;
class Vowel_Consonant
{
  char ch;
  void getdata()
  {
    System.out.println("Enter any Charcter : ");
    Scanner sc = new Scanner(System.in);
    ch = sc.next().charAt(0);
  }
  void process()
  {
     switch(ch)
     {
       case 'a' : System.out.println("Vowel");break;
       case 'e' : System.out.println("Vowel");break;
       case 'i' : System.out.println("Vowel");break;
       case 'o' : System.out.println("Vowel");break;
       case 'u' : System.out.println("Vowel");break;
       case 'A' : System.out.println("Vowel");break;
       case 'E' : System.out.println("Vowel");break;
       case 'I' : System.out.println("Vowel");break;
       case 'O' : System.out.println("Vowel");break;
       case 'U' : System.out.println("Vowel");break;
       default:System.out.println("Consonant");
     }
  }
  public static void main(String[] args)
  {
    Vowel_Consonant v = new Vowel_Consonant();
    v.getdata();
    v.process();
  }
} 