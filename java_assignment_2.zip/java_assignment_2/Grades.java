//24. WAP to display the grades of the student based on the following criteria.

import java.util.Scanner;
class Grades
{
  int marks;
  void getdata()
  {
    System.out.println("Enter the marks : ");
    Scanner sc = new Scanner(System.in);
    marks = sc.nextInt();
  } 
  void process()
  {
    if(marks>=90)
    System.out.println("Grade A");
    else if(marks>=80 && marks<90)
    System.out.println("Grade B");
    else if(marks>=60 && marks<80)
    System.out.println("Grade C");
    else if(marks>=45 && marks<60)
    System.out.println("Grade D");
    else
    System.out.println("Fail");
  }
  public static void main(String[] args)
  {
    Grades g = new Grades();
    g.getdata();
    g.process();
  }
}