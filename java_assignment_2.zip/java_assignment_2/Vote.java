//3. WAP to check whether a person is eligible to vote or not.

import java.util.Scanner;

class Vote
{
   int age;

   void getdata()
   {
     System.out.println("Enter your age : ");
     Scanner s = new Scanner(System.in);
     age = s.nextInt();
   }

   void display()
   {
     if(age >= 18)
     System.out.println("ELIGIBLE");
     else
     System.out.println("NOT ELIGIBLE");
   }


   public static void main(String[] args)
   {
     Vote v = new Vote();
     v.getdata();
     v.display();
   }
}

