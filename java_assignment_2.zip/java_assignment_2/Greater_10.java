//4. WAP to check whether a number is greater than 10 or not.

import java.util.Scanner;

class Greater_10
{
  int number;

  void getdata()
  {
    System.out.println("Enter a number : ");
    Scanner sc = new Scanner(System.in);
    number = sc.nextInt();
  }

  void process()
  {
    if(number > 10)
    System.out.println("GREATER");
    else if(number == 10)
    System.out.println("EQUAL");
    else 
    System.out.println("LESS");
  }
 
  public static void main(String[] args)
  {
    Greater_10 g = new Greater_10();
    g.getdata();
    g.process();
  }
 
} 