//10. WAP to check whether the entered character is alphabet or not alphabet.

import java.util.Scanner;

class Alphabet_check
{
  char alpha;
  int ascii;

  void getdata()
  {
    System.out.println("Enter any character : ");
    Scanner sc = new Scanner(System.in);
    alpha = sc.next().charAt(0);
    ascii = alpha;
  }
  
  void check()
  {
    if(ascii >= 65 && ascii <= 90)
    System.out.println("ALPHABET");
    else if(ascii >= 97 && ascii <= 122)
    System.out.println("ALPHABET");
    else
    System.out.println(" NOT AN ALPHABET");
  }

  public static void main(String[] args)
  {
    Alphabet_check a = new Alphabet_check();
    a.getdata();
    a.check();
  }
}