//16. WAP to check whether the average of five numbers is greater than 10 or not.

import java.util.Scanner;
  
class Average
{
  int num1, num2, num3, num4, num5, avg;
  void getdata()
  {
    System.out.println("Enter the five numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
    num3 = sc.nextInt();
    num4 = sc.nextInt();
    num5 = sc.nextInt();
  }
 
  void average()
  {
    avg = (num1 + num2 + num3 + num4 + num5) / 5;
  }

  void check()
  {
    if(avg > 10)
    System.out.println("Average is greaterthan 10");
    else if(avg < 10)
    System.out.println("Average is less than 10");
    else
    System.out.println("Average is 10");
  }

  public static void main(String[] args)
  {
    Average a = new Average();
    a.getdata();
    a.average();
    a.check();
  }
}