//14. WAP to check whether a character is vowel or consonant.

import java.util.Scanner;

class Vowel
{
  char ch;
  void getdata()
  {
    System.out.println("Enter any charcter : ");
    Scanner sc = new Scanner(System.in);
    ch = sc.next().charAt(0);
  }

  void check()
  {
    if(ch=='A' || ch=='E' ||ch=='I'||ch=='O'|| ch=='U')
    System.out.println("Vowel");
    else if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
    System.out.println("Vowel");
    else
    System.out.println("Consonant");
  }

  public static void main(String[] args)
  {
    Vowel v = new Vowel();
    v.getdata();
    v.check();
  }
}
