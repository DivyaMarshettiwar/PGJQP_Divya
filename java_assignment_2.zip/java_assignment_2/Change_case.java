//12.WAP to change the case of a character (from upper to lower or lower to upper).

import java.util.Scanner;

class Change_case
{
  char ch;
  int ascii;
  void getdata()
  {
    System.out.println("Enter any Character : ");
    Scanner sc = new Scanner(System.in);
    ch = sc.next().charAt(0);
    ascii = ch;
  }

  void change()
  {
    if(ascii>=65 && ascii<=90)
    System.out.println(Character.toLowerCase(ch));
    else
    System.out.println(Character.toUpperCase(ch));
  }

  public static void main(String[] args)
  {
    Change_case c = new Change_case();
    c.getdata();
    c.change();
  }
}