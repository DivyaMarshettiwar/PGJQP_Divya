//2. WAP to check whether a number is even or odd.

import java.util.Scanner;

class EvenOrOdd
{
   int number;
   void getdata()
   {
     System.out.println("Enter a number : " );
     Scanner s = new Scanner(System.in);
     number = s.nextInt();
   }

   void process()
   {
      if(number%2 == 0)
      System.out.println("THE NUMBER IS EVEN");
      else
      System.out.println("THE NUMBER IS ODD");
   }

   public static void main(String[] args)
   {
     EvenOrOdd ed = new EvenOrOdd();
     ed.getdata();
     ed.process();
   }
}