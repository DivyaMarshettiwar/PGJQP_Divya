//1. WAP to find the ASCII code for any character ( A-Z -> 65 to 90, a-z -> 97 to 122)
import java.util.Scanner;
class Alphabet
{
  char alpha;
  int value;
  void getdata()
  {
    System.out.println("Enter any Character : ");
    Scanner s = new Scanner(System.in);
    alpha = s.next().charAt(0);
  }
   
  void display()
  {
   value = alpha;
   System.out.println(value);
  }

  public static void main(String[] args)
  {
   Alphabet a = new Alphabet();
   a.getdata();
   a.display();
  }
  
}