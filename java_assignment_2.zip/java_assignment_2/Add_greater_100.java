//17. WAP to check whether the output of addition of two numbers is greater than 100 or not.

import java.util.Scanner;

class Add_greater_100
{
  int num1,num2,sum=0;
  void getdata()
  {
    System.out.println("Enter the two numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt(); 
  }

  void add()
  {
    sum = num1 + num2;
  }
  
  void check()
  {
    if(sum > 100)
    System.out.println("Addition is greater than 100");
    else if(sum < 100)
    System.out.println("Addition is less than 100");
    else
    System.out.println("Addition is 100");
  }

  public static void main(String[] args)
  {
    Add_greater_100 a = new Add_greater_100();
    a.getdata();
    a.add();
    a.check(); 
  }
}