//23. WAP to calculate the least of 3 numbers.

import java.util.Scanner;
class Least_of_3
{
  int num1, num2, num3;
  void getdata()
  {
    System.out.println("Enter the three numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
    num3 = sc.nextInt();
  }
  void process()
  {
    if(num1 < num2)
    {
       if(num1 < num3)
       System.out.println(num1 + " is smaller");
       else
       System.out.println(num3 + " is smaller");
    } 
    else
    {
       if(num2 < num3)
       System.out.println(num2 + " is smaller");   
       else
       System.out.println(num3 + " is smaller");
    }
  }
  public static void main(String[] args)
  {
    Least_of_3 l = new Least_of_3();
    l.getdata();
    l.process();
  }
}