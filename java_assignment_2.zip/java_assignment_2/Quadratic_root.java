//19. WAP to find all roots of a quadratic equation.

import java.util.Scanner;

class Quadratic_root
{
  double a, b, c, root1, root2, determinent;
  void getdata()
  {
    System.out.println("ax^2 + bx + c = 0");
    System.out.println("enter the value of a, b and c");
    Scanner sc = new Scanner(System.in);
    a = sc.nextDouble();
    b = sc.nextDouble();
    c = sc.nextDouble();
  }
  void process()
  {
    determinent = (b*b)-(4*a*c);
    root1 = (-b  + Math.sqrt(determinent)) / 2*a;
    root2 = (-b  - Math.sqrt(determinent)) / 2*a;
  }
  
  void display()
  {
    System.out.println(root1);
    System.out.println(root2);
  }

  public static void main(String[] args)
  {
    Quadratic_root q = new Quadratic_root();
    q.getdata();
    q.process();
    q.display();
  }
}