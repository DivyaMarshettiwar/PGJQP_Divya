//30. WAP to calculate the area of different polygons using switch case.

import java.util.Scanner;
class Polygons
{
  double length,breadth, area=0;
  int ch;
  Scanner sc = new Scanner(System.in);
  void getdata()
  {
    System.out.println("Enter your choice :");
    System.out.println("1.Rectangle");
    System.out.println("2.Square");
    
    ch = sc.nextInt();
  }
  void process()
  {
    switch(ch)
    {
      case 1:System.out.println("Enter the Length and Breadth : ");
             length = sc.nextDouble();
             breadth = sc.nextDouble();
             area = length*breadth;
             System.out.println(area);
             break;
      case 2:System.out.println("Enter the Length: ");
             length = sc.nextDouble();
             area = length*length;
             System.out.println(area);
             break;
      default: System.out.println("Invalid choice");
    }
  }
  public static void main(String[] args)
  {
    Polygons p = new Polygons();
    p.getdata();
    p.process();
  }
}