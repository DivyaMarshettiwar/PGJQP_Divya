//18. WAP to swap numbers without using 3rd variable.

import java.util.Scanner;
 
class Swap_2
{
  int num1, num2;
  void getdata()
  {
    System.out.println("enter the two numbers : ");
    Scanner sc = new Scanner(System.in);
    num1 = sc.nextInt();
    num2 = sc.nextInt();
  }
  
  void process()
  {
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
  }
 
  void display()
  {
    System.out.println("After Swapping");
    System.out.println("number 1 = " + num1);
    System.out.println("number 2 = " + num2);
  }

  public static void main(String[] args)
  {
    Swap_2 s = new Swap_2();
    s.getdata();
    s.process();
    s.display();
  }
} 