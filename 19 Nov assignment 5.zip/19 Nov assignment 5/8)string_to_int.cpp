//8. WAP to convert a string into int using predefined funnction.

#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

class Convert
{ 
	int num;
	string str;
	public:
		void getdata()
		{
			cout<<"Enter any string\n";
			cin>>str;
		}	
		
		void str_to_int()
		{
			num = atoi(str.c_str());
			cout<<num;	
		}
};

int main()
{
	Convert c1;
	c1.getdata();
	c1.str_to_int();
}
