//10). WAP to add two pointer variables.

#include<iostream>
using namespace std;

class Numbers
{
	int  num1,num2,*ptr1,*ptr2,result;
	public:
		void getdata()
		{
			cout<<"Enter any two numbers\n";
			cin>>num1>>num2;
			ptr1 = &num1;
			ptr2 = &num2;
			add();	
		}
		
		void add()
		{
			result = *ptr1 + *ptr2;
			cout<<"Addition is : "<<result;
		}
};

int main()
{
	Numbers n1;
	n1.getdata();
}
