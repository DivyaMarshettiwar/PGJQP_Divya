//5. WAP to implement even / odd, possitive / negative using functions.

#include<iostream>
using namespace std;

class Numbers
{
	int num;
	public:

		void getdata()
		{
			cout<<"Enter any number\n";
			cin>>num;
			even_odd();
		}
		
		void even_odd()
		{
			if(num % 2 == 0)
			cout<<"Even number\n";
			else
			cout<<"Odd number\n";
			pos_neg();
		}
		
		void pos_neg()
		{
			if(num >= 0)
			cout<<"Number is Positive\n";
			else
			cout<<"Number is Negative\n";
		}
};

int main()
{
	Numbers n1;
	n1.getdata();	
}
