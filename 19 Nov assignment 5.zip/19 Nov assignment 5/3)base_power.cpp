//3). WAP to calculate power of any  base using functions and return the value.

#include<iostream>
#include<cmath>
using namespace std;

class Numbers
{
	public:
	int base_power(int base, int power)
	{
		int result;
		result = pow(base,power);
		return result;
	}	
};

int main()
{
	int  base,power,ans;
	cout<<"Enter the base value\n";
	cin>>base;
	cout<<"Enter the power  value\n";
	cin>>power;
	Numbers n1;
	ans = n1.base_power(base,power);
	cout<<base<<" ^ "<<power<<" is : "<<ans;
}
