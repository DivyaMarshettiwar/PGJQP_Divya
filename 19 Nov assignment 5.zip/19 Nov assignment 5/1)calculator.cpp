//1. WAP to design a Calculator using switch case and implement functions for sum,sub,etc.

#include<iostream>
using namespace std;

 class Calculator
 {
 	int num1,num2,ch;
 	public:
 		
 		void getdata()
 		{
 			cout<<"Enter your choice \n";
			cout<<"1.ADDITION\t2.SUBTRACTION\t3.MULTIPLICATION\t4.DIVISION\n";
			cin>>ch;
			cout<<"Enter the two numbers\n";
			cin>>num1>>num2; 	
		}
		
		void display()
		{
			switch(ch)
			{
				case 1:cout<<"Addition is : "<<num1 + num2<<"\n";break;
				case 2:cout<<"Subtraction is : "<<num1 - num2<<"\n";break;
				case 3:cout<<"Multiplication is : "<<num1 * num2<<"\n";break;
				case 4:cout<<"Division is : "<<num1 / num2<<"\n";break;
				default: cout<<"invalid choice\n";
			}
		}
 };
 
 int main()
 {
 	Calculator c1;
 	c1.getdata();
 	c1.display();
 }
