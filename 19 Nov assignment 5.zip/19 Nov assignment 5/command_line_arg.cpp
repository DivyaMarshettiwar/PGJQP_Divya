//7). WAP to find the greater of 2 numbers using command line arguments.

#include<iostream>
#include<cstdlib>
using namespace std;

int main( int argc, char *argv[])
{
	if(argc == 3)
	{
		if(argv[1] > argv[2])
		{
			cout<<argv[1]<<" is greater\n";
		}
		else if(argv[1] == argv[2])
		{
			cout<<"Both are equal\n";
		}
		else
		cout<<argv[2]<<" is greater\n";
	}
	exit(1);
	return 0;
}
