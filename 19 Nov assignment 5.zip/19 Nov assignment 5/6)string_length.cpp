//6). WAP to find the length of the stringth.

#include<iostream>
#include<cstring>
using namespace std;

class Word
{
	char name[];
	public:
		void getdata()
		{
			cout<<"Enter your name\n";
			cin>>name;
		
		}
		
		void check()
		{
			cout<<"The length of the Name is : "<<strlen(name);
		}
};

int main()
{
	Word w1;
	w1.getdata();
	w1.check();
}
