//2. WAP to reverse a number using functions with parameters.

#include<iostream>
using namespace std;

class Numbers
{

	public:
		
		void display(int num)
		{
			int rev,rem;
			while(num > 0)
			{
				rem = num % 10;
				rev = rev * 10 + rem;
				num = num / 10;
			}
			cout<<"Reversed value is : "<<rev;
		}
};

int main()
{
	int value;
	cout<<"Enter any value \n";
	cin>>value;
	Numbers n1;
	n1.display(value);
}
