//9). WAP to find the address of any variable.

#include<iostream>
using namespace std;

class Numbers
{
	int num,*address;
	public:
		void getdata()
		{
			cout<<"Enter any number\n";
			cin>>num;
		}
		
		void address_number()
		{
			address = &num;
			cout<<"Adress is : "<<address;
		}
};

int main()
{
	Numbers n1;
	n1.getdata();
	n1.address_number();	
}
