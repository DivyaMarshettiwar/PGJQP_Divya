//4). WAP to find avg of five numbers using functions and then return the avg value to check whether the avg is greater than 100 or not.
#include<iostream>
using namespace std;

class Numbers
{
	int num1,num2,num3,num4,num5,avg;
	public:
		Numbers()
		{
			cout<<"To find the average any given five numbers\n";
		}
		
		~Numbers()
		{
			
		}
		
		void getdata()
		{
			cout<<"Enter the five numbers\n";
			cin>>num1>>num2>>num3>>num4>>num5;
			average();
		}
		
		void average()
		{
			avg = (num1 + num2 + num3 + num4 + num5) / 5;
			cout<<"Average is : "<<avg<<"\n";
			check();
		}
		
		void check()
		{
			if(avg > 100)
			cout<<"Average is greater than 100\n";
			else if(avg == 100)
			cout<<"Average is equal to 100\n";
			else
			cout<<"Average is less than 100\n";
		}
};

int main()
{
	Numbers n1;
	n1.getdata();
}
